const express = require('express');
const mongoose = require('mongoose');
const config = require('./config/db')
const userRoutes = require('./routes/userRoutes');
const merchRoutes = require('./routes/merchRoutes');
const cors = require('cors');
const bodyParser = require('body-parser');
const errorHandler = require('./middlewares/errorHandler')

const app = express();

app.use(cors());
app.use(bodyParser.json())

const uri = "mongodb+srv://admin:admin123@cluster0.guvch.mongodb.net/fashionista?retryWrites=true&w=majority";
mongoose.Promise = global.Promise;
mongoose.connect(uri, {useUnifiedTopology: true,useNewUrlParser: true })
.then(()=>{
    console.log('Connected to db');
})

app.use('/user', userRoutes);
app.use('/merch', merchRoutes);
//app.use(errorHandler)


app.listen(config.PORT, ()=>{
    console.log(`Listening on port: ${config.PORT}`)
})