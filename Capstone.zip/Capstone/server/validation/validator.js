const {body} = require('express-validator');

exports.isEmail = body('email')
.exists()
.isEmail()
.withMessage('Must be a valid Email')

exports.hasPassword = body('password')
.exists()
.withMessage('Password cannot be empty')

exports.hasName = body('name')
.exists()
.withMessage('Name is required')

exports.hasPrice = body('price')
.exists()
.isNumeric()
.withMessage('Price is required')

exports.hasType = body('usertype')
.exists()
.withMessage('User type is required')

