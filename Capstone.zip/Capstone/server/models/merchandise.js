const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const MerchSchema = new Schema({
    name: {type: String, required: true},
    categories: [{type: String}],
    price: {type: Number, required: true},
    description : {type: String, required: false},
    image: {type: String, required: true}
})

module.exports =  mongoose.model('Merch', MerchSchema);