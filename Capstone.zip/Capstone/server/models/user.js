const mongoose = require('mongoose');
const bcrypt = require('bcrypt');

const Schema = mongoose.Schema;

const UserSchema = new Schema({
    name: {type: String, required: true},
    email: {type: String, required: true},
    password: {type: String, required: true, select: false},
    purchased: [{type: Schema.Types.ObjectId, ref: 'Merch'}],
    wishlist: [{type: Schema.Types.ObjectId, ref: 'Merch'}],
    cart: [{type: Schema.Types.ObjectId, ref: 'Merch'}],
    usertype:  {type: String, required: true}
})

UserSchema.methods.encryptPassword = async (password) =>{
    const salt = await bcrypt.genSalt(5);
    const hash = await bcrypt.hash(password, salt);
    return hash;
}

UserSchema.methods.validPassword = async (candidatePass, userPass) =>{
    const result = await bcrypt.compare(candidatePass, userPass);
    return result;
}

module.exports =  mongoose.model('User', UserSchema);