const Merch = require('../models/merchandise');
const User = require ('../models/user');
const validationHandler = require('../validation/validationHandler')

exports.index = async (req,res,next) =>{
    try{

        const merchandise = await Merch.find();
        res.send(merchandise)

    } catch(err){
        next(err)
    }
}

exports.findOne = async (req,res,next) =>{
    try{

        const merchandise = await Merch.findById(req.params.id);
        res.send(merchandise)

    } catch(err){
        next(err)
    }
}

exports.update = async (req,res,next) =>{
    try{
        validationHandler(req)

        let merchandise = await Merch.findById(req.body.id)
        if(!merchandise){
            console.log('Merch not found')
            const error = new Error('Item was not found');
            error.statusCode = 404;
            throw error;
        }

        merchandise.name = req.body.name;
        merchandise.price = req.body.price;
        merchandise.description = req.body.description;
        merchandise.image = req.body.image;
        merchandise.categories = req.body.categories;

        merchandise = merchandise.save();

        res.send(merchandise)

    } catch(err){
        next(err)
    }
}

exports.store = async (req,res,next) =>{

    try{

        validationHandler(req);
        
        let merch = new Merch();
        merch.name = req.body.name;
        merch.price = req.body.price;
        merch.description = req.body.description;
        merch.categories = req.body.categories;
        merch.image = req.body.image;
        merch = await merch.save();

        res.send(merch);

    }catch(err){
        next(err)
    }
};

exports.delete = async (req,res,next) =>{
console.log('here')
    try{

        console.log(req.query.id)
        let merch = await Merch.findById(req.query.id);


        if(!merch){
            const error = new Error('Item not Found');
            error.statusCode = 404;
            throw error;
        }

        await merch.delete();

        res.send({message: 'Successfully deleted'});

    }catch(err){
        next(err)
    }

};

exports.addToCart = async (req,res,next) =>{
    try{


    let user = await User.findById(req.body.user._id)
    let merch = await Merch.findById(req.body.merch.id)

    if(!user || !merch)
    {
        const error = new Error('Item or User not found');
        console.log('err in add to cart')
        error.statusCode = 404;
        throw error;
    }

    let cart = user.cart;
    cart.push(merch)
    user.cart = cart;
    user = await user.save();

    res.send(user);


    }catch(err){
        next(err)
    }

}

exports.addToWishList = async (req,res,next) =>{
    try{


    let user = await User.findById(req.body.user._id)
    let merch = await Merch.findById(req.body.merch.id)

    if(!user || !merch)
    {
        const error = new Error('Item or User not found');
        console.log('err in add to cart')
        error.statusCode = 404;
        throw error;
    }

    let wishlist = user.wishlist;
    wishlist.push(merch)
    user.wishlist = wishlist;
    user = await user.save();

    res.send(user);


    }catch(err){
        next(err)
    }
}

exports.purchase = async (req,res,next) =>{
    try{


    let user = await User.findById(req.body.user._id).populate('cart')
    let merch = await Merch.findById(req.body.merch.id)

    if(!user || !merch)
    {
        const error = new Error('Item or User not found');
        error.statusCode = 404;
        throw error;
    }


    //add logic
    user.cart.pull(req.body.merch.id);
    user.purchased.push(merch);
    user.save();
    res.send(user)

    }catch(err){
        next(err)
    }
}

exports.purchaseAll = async (req,res,next) =>{
    try{

        console.log('here')

    let user = await User.findById(req.body.user._id).populate('cart')

    if(!user)
    {
        const error = new Error(' User not found');
        error.statusCode = 404;
        throw error;
    }

    let cart = user.cart;
    let purchased = user.purchased;

    for(item of cart)
    {
        purchased.push(item)
    }
    
    user.purchased = purchased;
    user.cart = [];
    user = await user.save();

    res.send(user);


    }catch(err){
        next(err)
    }
}

exports.removeFromCart = async (req,res,next) =>{

    let user = await User.findById(req.body.user._id).populate('cart');

    if(!user)
    {
        const error = new Error(' User not found');
        error.statusCode = 404;
        throw error;
    }


   user.cart.pull(req.body.merch.id)
   user = user.save();
   res.send(user);
}

