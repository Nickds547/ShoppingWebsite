const User = require('../models/user');
const Merch = require ('../models/merchandise')
const jwt = require('jwt-simple');
const validationHandler = require('../validation/validationHandler');
const config = require('../config/db')

exports.login = async (req,res,next) =>{
    try{

        const email = req.body.email;
        const password = req.body.password;
        const user = await User.findOne({email}).select('+password');

        if(!user){
            console.log('No User Found')
            const error = new Error('Wrong Credentials');
            error.statusCode = 401;
            error.message='Wrong Credentials';
            throw error;
        }

        const validPassword = await user.validPassword(password,user.password);
        if(!validPassword){
            console.log('Incorrect Password')
            const error = new Error('Wrong Credentials');
            error.statusCode = 401;
            error.message='Wrong Credentials';
            throw error;
        }

        const token = jwt.encode({id: user.id}, config.jwtSecret);
        res.send({user, token});

    } catch(err){
        next(err)
    }
}

exports.signup = async (req,res,next) =>{
    try{


        validationHandler(req);

        const existingUser = await User.findOne({email: req.body.email})

        if(existingUser){
            const error = new Error('Email already in use');
            error.statusCode = 403;
            throw error;
        }


        let user = new User();
        user.email = req.body.email;
        user.password = await user.encryptPassword(req.body.password);
        user.name = req.body.name;
        user.usertype= req.body.usertype;
        user = await user.save();

        return res.send({user});

    } catch(err){
        next(err)
    }
}

exports.me = async (req,res,next) =>{
    try{
        const user = await User.findById(req.body.id).populate('cart');
        return res.send(user)

    } catch(err) {
        next(err)
    }
    
    res.send(user)
}

exports.index = async (req,res,next) =>{
    try{
        const users = await User.find();
        res.send(users)

    } catch(err){
        next(err)
    }
}

exports.update = async (req,res,next) =>{

    let user = await User.findById(req.body.id);
    if(!user){
        let err = new Error('User could not be found');
        err.statusCode = 404;
        throw err;
    }

    user.name = req.body.name;
    user.email = req.body.email;

   user = await user.save();

   res.send(user);
}

exports.delete = async (req,res,next) =>{

    try{

        let user = await User.findById(req.query.id);


        if(!user){
            const error = new Error('Item not Found');
            error.statusCode = 404;
            throw error;
        }

        await user.delete();

        res.send({message: 'Successfully deleted'});

    }catch(err){
        next(err)
    }

};