const express = require('express');
const router = express.Router();
const passportJWT = require('../middlewares/passportJWT')();
const merchController = require('../controllers/merchController');


router.post('/', merchController.store);
router.get('/', merchController.index);
router.patch('/', merchController.update);
router.delete('/', merchController.delete)
router.get('/:id', merchController.findOne);
router.post('/addToCart', merchController.addToCart);
router.post('/addToWishlist', merchController.addToWishList);
router.post('/purchaseall', merchController.purchaseAll);
router.post('/removefromcart', merchController.removeFromCart);
router.post('/purchase', merchController.purchase)

module.exports = router;