const express = require('express');
const router = express.Router();
const passportJWT = require('../middlewares/passportJWT')();
const authController = require('../controllers/userController');
const {isEmail,hasName,hasPassword, hasType} = require('../validation/validator');


router.post('/login', authController.login);
router.post('/signup', [isEmail,hasName,hasPassword, hasType], authController.signup);
router.post('/me', authController.me);
router.get('/', authController.index);
router.patch('/', authController.update)
router.delete('/', authController.delete)

module.exports = router;