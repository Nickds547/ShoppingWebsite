exports.PORT = 8080;

exports.jwtSecret = "navljsk9823hjfa";