import { Component, OnInit } from '@angular/core';
import {FormControl,Validators,FormGroup, FormBuilder, Validator, FormArray} from '@angular/forms';
import { Merch } from '../imports/classes';
import {MerchService} from '../services/merch.service'



interface addObject{
  success: boolean,
  message: String
}

@Component({
  selector: 'app-add-merch',
  templateUrl: './add-merch.component.html',
  styleUrls: ['./add-merch.component.css']
})
export class AddMerchComponent implements OnInit {

  constructor( private formBuilder: FormBuilder, private merchService: MerchService) { }

  addedItems: Array<addObject> = [];

  addMerchForm = this.formBuilder.group({
    fields: new FormArray([])
  })

  
  get f() {return this.addMerchForm.controls}
  get m() {return this.f.fields as FormArray}


  ngOnInit(): void {
    this.addField();
  }


  addField = () =>{
    this.m.push(this.formBuilder.group({
      name: ['', Validators.required],
      price: ['', Validators.required, !isNaN],
      image: ['', Validators.required],
      categories: ['', Validators.required],
      description: [''],
    }));
  }

  addItem = (index) =>{

    let form = this.m.at(index).value;
    let categories: Array<String> = form.categories.split(',')

    if (this.addMerchForm.invalid) {
      console.log('Form invalid')
      this.addedItems[index] = {success: false, message: 'All fields must be completed'}
      console.log(this.addedItems)
      return;
    }
    else{
      let merch = new Merch(form.name,categories,form.price,form.description, form.image)

      this.merchService.addMerch(merch).subscribe(
        data =>{

          this.addedItems[index] = {success: true, message: `${form.name} was added successfully`}
          console.log('data: ', data);
        },
        err =>{
          this.addedItems[index] = {success: false, message: `Item # ${index + 1} could not be added at this time`}
          console.log(err)
        }
      )

    }

  }

  deleteItem = (index) =>{
    this.m.removeAt(index);
  }

}
