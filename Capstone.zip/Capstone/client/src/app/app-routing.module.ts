import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import * as Components from './imports/components';
import * as Guards from './imports/guards';

const routes: Routes = [
  {path: '', component: Components.CustLandingComponent, canActivate: [Guards.AuthGuard]},
  {path:'cart', component: Components.CartComponent, canActivate: [Guards.AuthGuard]},
  {path: 'admin', component: Components.AdminlandingComponent, canActivate: [Guards.AuthGuard,Guards.AdminGuard]},

  {path: 'login', component: Components.LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
