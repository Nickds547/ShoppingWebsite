import { Component, OnInit } from '@angular/core';
import {MerchService} from '../services/merch.service';
import {FormControl,Validators,FormGroup, FormBuilder, Validator, FormArray} from '@angular/forms'
import { Merch } from '../imports/classes';

interface messageObj{
  success: boolean,
  message: String
}

@Component({
  selector: 'app-adminlanding',
  templateUrl: './adminlanding.component.html',
  styleUrls: ['./adminlanding.component.css']
})
export class AdminlandingComponent implements OnInit {


  merchData: Array<any> = [];
  title: String = 'Merchandise';
  editItem: any = new Merch('',[''],0,'','');
  editForm: FormGroup = new FormGroup({});
  name: FormControl;
  price: FormControl;
  categories: FormControl;
  image: FormControl;
  description: FormControl;

  notificationMessages: Array<messageObj> = [];


  constructor(private merchService: MerchService) { }


   ngOnInit(): void {

    this.getData();
    this.createFormControls();
    this.createForm();
  }


  changeTitle = (newTitle)=>{
    if(newTitle === 'Merchandise')
    {
      this.getData();
    }


    this.title = newTitle;
  }

  getData = async () =>{
    
    await this.merchService.getMerch().subscribe((data) =>{
      if(data.length != 0){
        this.merchData = data;
        this.editItem = data[0]
      }
    })
  }

  showItem = (index) =>{
    this.editItem = this.merchData[index];

    document.getElementById('itemHeader').innerHTML = this.editItem.name //using this function because interpolation doesnt work for some reason

    this.createFormControls();
    this.createForm();
  }

  createFormControls(){
    this.name = new FormControl(this.editItem.name, [Validators.required]);
    this.price = new FormControl(this.editItem.price, [Validators.required]);
    this.categories = new FormControl(this.editItem.categories, [Validators.required]);
    this.image = new FormControl(this.editItem.image, [Validators.required]);
    this.description = new FormControl(this.editItem.description);
  }

  createForm(){
    this.editForm = new FormGroup({
      name: this.name,
      price: this.price,
      categories: this.categories,
      image: this.image,
      description: this.description
    })
  }

  confirmEdit = () =>{

    let merch = new Merch(this.name.value, this.categories.value,this.price.value, this.description.value, this.image.value);
    merch.id = this.editItem._id
    this.merchService.editMerch(merch).subscribe(
      data =>{
        this.getData();
        this.notificationMessages.push({success: true, message: `${merch.name} was sucessfully changed`})
      },
      err =>{
        this.notificationMessages.push({success: false, message: `${merch.name} was not changed`});
      }
    )
  }

  delete = (index) =>{
    let item = this.merchData[index]

    if(confirm("Are you sure to delete "+item.name)) {
      this.merchService.deleteMerch(item._id).subscribe(
        data =>{
          this.notificationMessages.push({success: true, message: `Item was sucessfully deleted`})
        },
        err =>{
          console.log(err)
          this.notificationMessages.push({success: false, message: `Item was not deleted at this time`})
        }
      )
    }

    this.getData()

  }
  

}
