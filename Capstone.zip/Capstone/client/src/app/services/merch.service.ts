import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {LINK} from '../imports/server';
import { Observable } from 'rxjs';
import {Merch} from '../imports/classes';
import {CookieService} from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class MerchService {

  link: String = LINK + '/merch'
  headers = { 'Content-Type': 'application/json'}  


  constructor(private http: HttpClient, private cookie: CookieService) { }

  getMerch = (): Observable<any> =>{

    return this.http.get(this.link + '/');
  }

  addMerch = (merch: Merch): Observable<any> =>{

    const body = JSON.stringify(merch);

    return this.http.post(this.link + '/', body, {'headers': this.headers})
  }

  editMerch = (merch: Merch): Observable<any> =>{
    const body = JSON.stringify(merch);
    console.log('upodate body ' + body)

    return this.http.patch(this.link + '/', body, {'headers': this.headers})
  }

  deleteMerch = (id): Observable<any> =>{

    return this.http.delete(this.link + '/',{
      params:{
        id: id
      }
    })
  }

  addToCart = (merch: Merch): Observable<any> =>{
    const user = JSON.parse(this.cookie.get('user'));
    const body = JSON.stringify({user: user, merch: merch});

    return this.http.post(this.link + '/addToCart', body, {'headers': this.headers})
  }

  addToWishlist = ( merch : Merch): Observable<any> =>{
    const user = JSON.parse(this.cookie.get('user'));
    const body = JSON.stringify({user: user, merch: merch});
    return this.http.post(this.link + '/addToWishlist', body, {'headers': this.headers})

  }

  purchaseAll = ( merch : Merch): Observable<any> =>{ 

    const user = JSON.parse(this.cookie.get('user'));
    const body = JSON.stringify({user: user, merch: merch});

    return this.http.post(this.link + '/purchaseall', body, {'headers': this.headers})
  }

  removeFromCart = ( merch : Merch): Observable<any> =>{ 
  
    const user = JSON.parse(this.cookie.get('user'));
    const body = JSON.stringify({user: user, merch: merch});

    return this.http.post(this.link + '/removefromcart', body, {'headers': this.headers})
  
  }

  purchase = ( merch : Merch): Observable<any> =>{ 
    const user = JSON.parse(this.cookie.get('user'));
    const body = JSON.stringify({user: user, merch: merch});

    return this.http.post(this.link + '/purchase', body, {'headers': this.headers})
  }

}
