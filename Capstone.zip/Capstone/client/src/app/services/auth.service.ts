import { Injectable } from '@angular/core';
import {LINK} from '../imports/server'
import {HttpClient} from '@angular/common/http'
import {User} from '../imports/classes'
import { Observable } from 'rxjs';
import { JwtHelperService } from '@auth0/angular-jwt';
import {CookieService} from 'ngx-cookie-service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  link = LINK + '/user'
  headers = { 'Content-Type': 'application/json'}  

  constructor(private http: HttpClient, private jwt: JwtHelperService, private cookie: CookieService) { }

  login = (email, password): Observable<any> =>{
    const body=JSON.stringify({email: email, password: password});


    return this.http.post(this.link + '/login', body, { 'headers': this.headers })

  }

  register = (user: User): Observable<any> =>{
    if(!user.usertype)
      user.usertype = 'customer';

    const body = JSON.stringify(user)

    return this.http.post(this.link + '/signup', body, {'headers': this.headers} )
  }

  isAuthenticated = (): boolean =>{

    const token = this.cookie.get('token');

    return !this.jwt.isTokenExpired(token);
  }

  getAll = (): Observable<any> =>{

    return this.http.get(this.link + '/')
  }

  update = (user: User): Observable<any> =>{
    const body = JSON.stringify(user)
    return this.http.patch(this.link + '/', body, {'headers':  this.headers})
  }

  delete = (user: User): Observable<any> =>{
    return this.http.delete(this.link + '/',{
      params:{
        id: user.id
      }
    })
  }

  me = (id: String): Observable<any> =>{
    const body = JSON.stringify({id: id})
    return this.http.post(this.link + '/me', body, {'headers': this.headers})
  }

}
