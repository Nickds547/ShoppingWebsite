import { Component, OnInit } from '@angular/core';
import {Merch} from '../imports/classes';
import {CookieService} from 'ngx-cookie-service';
import {MerchService} from '../services/merch.service'
import {AuthService} from '../services/auth.service'

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartArray = [];
  totalPrice = 0;
  userId
  
  constructor(private merchService: MerchService, private cookie: CookieService, private autheService: AuthService) { }

  ngOnInit(): void {
    this.getData()
  }

  purchaseAll = () =>{

    if(confirm("Are you sure want to purchase all items for "+ this.totalPrice)) {
      this.merchService.purchaseAll(this.userId).subscribe(
        data =>{
          console.log(data)
          this.getData();
        },
        err =>{
          console.log(err)
        }
      )
    }
  }


  getData = () =>{

    this.userId = JSON.parse(this.cookie.get('user'))._id;
    this.autheService.me(this.userId ).subscribe(
      data =>{
        this.cartArray = data.cart;

        for(let item of this.cartArray){
          this.totalPrice +=   parseInt(item.price);
        }
      },

      err =>{
        console.log(err)
      }
    )

  }

  remove = (item) =>{

    let merch = new Merch(item.name, item.categories,item.price,item.description,item.iamge);
    merch.id = item._id

    console.log(item)
    if(confirm("Are you sure want to remove "+ item.name + ' from your cart?')) {
      this.merchService.removeFromCart(merch).subscribe(
        data =>{

        },
        err => {
          console.log(err)
        }
      )
    }

  }

  buy = (item) =>{
    let merch = new Merch(item.name, item.categories,item.price,item.description,item.iamge);
    merch.id = item._id

    if(confirm("Are you sure want to buy "+ item.name + ' for ' + item.price)) {
      this.merchService.purchase(merch).subscribe(
        data =>{
          console.log(data)
        },
        err => {
          console.log(err)
        }
      )
    }

  }
}
