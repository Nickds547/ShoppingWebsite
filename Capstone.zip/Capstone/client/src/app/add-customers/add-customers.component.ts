import { Component, Input, OnInit } from '@angular/core';
import {FormControl,Validators,FormGroup, FormBuilder, Validator, FormArray} from '@angular/forms';
import {User} from '../imports/classes';
import {AuthService} from '../services/auth.service';



@Component({
  selector: 'app-add-customers',
  templateUrl: './add-customers.component.html',
  styleUrls: ['./add-customers.component.css']
})
export class AddCustomersComponent implements OnInit {

  @Input() getData: () => void;

  constructor(private formBuilder: FormBuilder, private auth: AuthService) { }

  addCustomerForm = this.formBuilder.group({
    fields: new FormArray([])
  });

  get f() {return this.addCustomerForm.controls}
  get m() {return this.f.fields as FormArray}


  ngOnInit(): void {
    this.addField();
    console.log(this.m.controls)
  }

  addField = () =>{
    this.m.push(this.formBuilder.group({
      name: ['', Validators.required],
      email:  ['', Validators.required],
      password: ['', Validators.required],
      usertype: ['', Validators.required]
    }))
  }

  deleteItem = (index)=>{
    console.log('in delete')
    this.m.removeAt(index);
  }

  addUser = (index) =>{
    let form = this.m.at(index)

    console.log(form.value)
    if(form.invalid){
      alert('All fields must be entered')
      return;
    }
    else{
      let user = new User(form.value.name,form.value.email);
      user.password = form.value.password;
      user.usertype = form.value.usertype;

      this.auth.register(user).subscribe(
        data =>{
          console.log(data)
          this.getData()
        },
        err =>{
          console.log(err)
        }
      )

      console.log(user)
    }
  }

}
