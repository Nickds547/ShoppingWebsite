import { Component, OnInit, Input } from '@angular/core';
import {FormControl,Validator,Validators,FormGroup} from '@angular/forms';
import isEmail from '../imports/validation';
import {AuthService} from '../services/auth.service';
import {User} from '../imports/classes';
import {CookieService} from 'ngx-cookie-service';

@Component({
  selector: 'app-register-form',
  templateUrl: './register-form.component.html',
  styleUrls: ['./register-form.component.css']
})
export class RegisterFormComponent implements OnInit {

  @Input() switchLogin: () => void;
  registerForm: FormGroup;
  name: FormControl;
  email: FormControl;
  password: FormControl;

  registerError: boolean = false;

  constructor(private auth: AuthService) { }

  ngOnInit(): void {
    this.createFormControls();
    this.createForm();
  }

  createFormControls(){
    this.name = new FormControl('', Validators.required);
    this.email = new FormControl('', [Validators.required, isEmail]);
    this.password = new FormControl('', Validators.required);
  }

  createForm(){
    this.registerForm = new FormGroup({
      name: this.name,
      email: this.email,
      password: this.password
    })
  }

  switchRegister = () =>{
    this.switchLogin()
  }

  register(){
    let user = new User(this.name.value, this.email.value);
    console.log('in register')

    user.password = this.password.value;

    this.auth.register(user).subscribe(
      data =>{
        console.log(data);
        this.switchLogin()
      },

      err =>{
        this.registerError = true;
      }
    )
  }

}
