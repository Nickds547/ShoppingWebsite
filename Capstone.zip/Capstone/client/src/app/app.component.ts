import { Component } from '@angular/core';
import {CookieService} from 'ngx-cookie-service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{
  
  title = 'client';
  verified: boolean = false;
  name: String;

  constructor(private cookie: CookieService){
  }

  ngOnInit(){
  }

  ngDoCheck(){
    if(this.cookie.get('token'))
    {
      this.verified = true;
      let user = JSON.parse(this.cookie.get('user'))
      this.name = user.name;
    }
    else{
      this.verified = false;
    }
  }

}
