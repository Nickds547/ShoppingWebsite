import {NavbarComponent} from '../navbar/navbar.component';
import {LoginComponent} from '../login/login.component';
import {AdminlandingComponent} from '../adminlanding/adminlanding.component';
import {AppComponent} from '../app.component';
import {CartComponent} from '../cart/cart.component'
import {CustLandingComponent} from '../cust-landing/cust-landing.component'

export {
    NavbarComponent,
    LoginComponent,
    AdminlandingComponent,
    AppComponent,
    CartComponent,
    CustLandingComponent
}