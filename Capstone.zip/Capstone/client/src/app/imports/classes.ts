export class User{

    name: string;
    email: string;
    password: String;
    purchased: Array<Merch>;
    wishlist: Array<Merch>;
    cart: Array<Merch>;
    usertype: string;
    id: string


    constructor(name: string, email: string){
        this.name = name;
        this.email = email;
    }


}



export class Merch{

    name: String;
    categories: Array<String>;
    price: number;
    image: String;
    description : String
    id: string;

    constructor(name: String, categories: Array<String>, price: number, description: String, image: String){
        this.name = name;
        this.categories = categories;
        this.price = price;
        this.description = description;
        this.image = image;
    }
}

export class MerchForm{
    name: String;
    categories: Array<String>
}