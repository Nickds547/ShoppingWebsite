import {FormControl} from '@angular/forms'
import { ɵCompiler_compileModuleSync__POST_R3__ } from '@angular/core';


const isEmail = (control: FormControl) =>{

    let email = control.value;
    if(email && email.indexOf("@") && email.indexOf(".") != -1){
      if(email.indexOf("@") !=-1) //For some reason this had to be added twice
      {
        return null;
      }
    }
    return email;
  }
export default (isEmail)