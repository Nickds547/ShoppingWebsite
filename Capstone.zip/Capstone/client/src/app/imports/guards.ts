import {AdminGuard} from '../guards/admin.guard';
import {AuthGuard} from '../guards/auth.guard';

export {
    AdminGuard,
    AuthGuard
}