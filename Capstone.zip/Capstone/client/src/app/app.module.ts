import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms'
import { CookieService} from 'ngx-cookie-service'
import {HttpClientModule} from '@angular/common/http'
import { JwtModule } from '@auth0/angular-jwt';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { LoginComponent } from './login/login.component';
import { AdminlandingComponent } from './adminlanding/adminlanding.component';
import { StartpageComponent } from './startpage/startpage.component';
import { RegisterFormComponent } from './register-form/register-form.component';
import { CartComponent } from './cart/cart.component';
import { CustLandingComponent } from './cust-landing/cust-landing.component';
import { AddMerchComponent } from './add-merch/add-merch.component';
import { ViewCustomersComponent } from './view-customers/view-customers.component';
import { AddCustomersComponent } from './add-customers/add-customers.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    LoginComponent,
    AdminlandingComponent,
    StartpageComponent,
    RegisterFormComponent,
    CartComponent,
    CustLandingComponent,
    AddMerchComponent,
    ViewCustomersComponent,
    AddCustomersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: ()=>{
          console.log('app.moudle token' + localStorage.getItem('token'))
          return localStorage.getItem('token')
        }
      }
    })
  ],
  providers: [
    CookieService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
