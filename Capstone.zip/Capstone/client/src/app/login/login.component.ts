import { Component, OnInit, Input } from '@angular/core';
import {FormControl,Validator,Validators,FormGroup} from '@angular/forms'
import {AuthService} from '../services/auth.service'
import isEmail from '../imports/validation'
import { CookieService } from 'ngx-cookie-service';
import {JwtHelperService} from '@auth0/angular-jwt'
import {Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @Input() switchVerified: () => void;

  loginForm: FormGroup;
  email: FormControl;
  password: FormControl;
  register: boolean = false;
  badCredentials: boolean = false;

  constructor(private auth: AuthService, private cookieService: CookieService, private router: Router, private jwt: JwtHelperService) { }

  ngOnInit(): void {
    this.createFormControls();
    this.createForm();
  }

  createFormControls(){
    this.email = new FormControl('', [Validators.required, isEmail]);
    this.password = new FormControl('', Validators.required)
  }

  createForm(){
    this.loginForm = new FormGroup({
      email: this.email,
      password: this.password
    })
  }

  login(){
    
    this.auth.login(this.email.value, this.password.value).subscribe(
      data => {
        let now = new Date();
        now.setHours(now.getHours() + 2) //seting a time 2 hours from creation to expire

        let user = data.user;
        user.password = ''; //removing hashed password so it is not stored in the cookie
        this.cookieService.set('token', data.token, now);
        this.cookieService.set('user', JSON.stringify(user))
        this.router.navigate(['']);
      },
      err =>{
        console.log(err)
        this.badCredentials = true;
        console.log('err')

      }
    )

  }


  switchRegister = ()=>{
    this.register = !this.register;
  }

}
