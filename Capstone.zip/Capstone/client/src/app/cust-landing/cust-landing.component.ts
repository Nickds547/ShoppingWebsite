import { Component, OnInit } from '@angular/core';
import {MerchService} from '../services/merch.service';
import {Merch} from '../imports/classes'
import {CookieService} from 'ngx-cookie-service';

@Component({
  selector: 'app-cust-landing',
  templateUrl: './cust-landing.component.html',
  styleUrls: ['./cust-landing.component.css']
})
export class CustLandingComponent implements OnInit {


  merchData;
  dataMap = new Map<String,Array<Merch>>();
  viewedItem: Merch = new Merch('',[],0,'','');

  constructor(private merchService: MerchService, private cookie: CookieService) { }

  ngOnInit(): void {
    this.merchService.getMerch().subscribe(
      data =>{
        this.merchData = data;

        for(let i = 0; i < data.length; i++){
          let arr = this.dataMap.get(data[i].categories);

          if(arr)
          {
            arr.push(data[i])
            this.dataMap.set(data[i].categories, arr);
          }
          else{
            let newArray = [];
            newArray.push(data[i])
            this.dataMap.set(data[i].categories,newArray)
          }

        }
      },
      err=>{
        console.log(err);
      }
    )
  }


  seeMore = (item) =>{
    let merch = new Merch(item.name,item.categories,item.price, item.description,item.image)
    merch.id = item._id
    this.viewedItem = merch;
  }

  addCart = (item) =>{

    let merch = new Merch(item.name,item.categories,item.price, item.description,item.image)
    if(item._id)
      merch.id = item._id
    else if(this.viewedItem.id)
      merch.id = this.viewedItem.id

    this.merchService.addToCart(merch).subscribe(
      data =>{
        console.log(data)
        this.cookie.set('user', JSON.stringify(data))
        alert('Item added to cart')
      },
      err => {
        console.log(err)
      }
    )
  }

  wishList = (item) =>{
    let merch = new Merch(item.name,item.categories,item.price, item.description,item.image)
    if(item._id)
      merch.id = item._id
    else if(this.viewedItem.id)
      merch.id = this.viewedItem.id

      this.merchService.addToWishlist(merch).subscribe(
        data =>{
          alert('Added to wishlist')
        },
        err =>{
          console.log(err)
        }
      )

  }

}
