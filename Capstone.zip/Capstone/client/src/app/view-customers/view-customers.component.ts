import { Component, OnInit } from '@angular/core';
import {AuthService} from '../services/auth.service';
import {User} from '../imports/classes';
import {FormControl,Validators,FormGroup, FormBuilder, Validator, FormArray} from '@angular/forms'

@Component({
  selector: 'app-view-customers',
  templateUrl: './view-customers.component.html',
  styleUrls: ['./view-customers.component.css']
})
export class ViewCustomersComponent implements OnInit {

  custData: Array<User> = [];
  adminData: Array<User> = [];
  userToEdit: User = new User('','');
  editForm: FormGroup = new FormGroup({});
  name: FormControl;
  email: FormControl;

  constructor(private authService: AuthService) { }

  ngOnInit(): void {

    this.getUserList();
    this.createFormControls();
    this.createForm();
  }

  getUserList = () =>{

    this.custData = [];
    this.adminData  = [];

    this.authService.getAll().subscribe(
      data=>{
        if(data.length != 0){

          for(let i = 0; i < data.length; i++){
            let cust = new User(data[i].name,data[i].email);
            cust.cart = data[i].cart;
            cust.purchased = data[i].purchased;
            cust.wishlist = data[i].wishlist;
            cust.usertype = data[i].usertype;
            cust.id = data[i]._id

            if(cust.usertype == 'customer')
              this.custData.push(cust)
            else if(cust.usertype == 'admin')
              this.adminData.push(cust)
          }

        }
      }
    )
  }

  editUser = (user: User) =>{

    this.userToEdit = user;
    this.createFormControls();
    this.createForm();
  }

  deleteUser = (user: User) =>{

    if(confirm("Are you sure to delete "+ user.name)) {
      this.authService.delete(user).subscribe(
        data =>{
          console.log(data)
        },
        err =>{
          console.log(err)
        }
      )
    }

  }


  createFormControls(){
    this.name = new FormControl(this.userToEdit.name, [Validators.required]);
    this.email = new FormControl(this.userToEdit.email, [Validators.required]);
  }

  createForm(){
    this.editForm = new FormGroup({
      name: this.name,
      email: this.email,
    })
  }

  confirmEdit = () =>{

    let user = new User(this.name.value, this.email.value)
    user.id= this.userToEdit.id;

    this.authService.update(user).subscribe(
      data=>{
        console.log(data)
        alert('User successfully edited')
      },
      err =>{
        console.log(err)
        alert('User was not edited')
      }
    )

    this.getUserList()

  }

}
