import { Component, OnInit, Input } from '@angular/core';
import {FormGroup} from '@angular/forms'
import { CookieService } from 'ngx-cookie-service';
import {Router} from '@angular/router'

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {

  logoutForm: FormGroup = new FormGroup({});
  isAdmin: boolean = false;

  constructor(private cookieService: CookieService, private router: Router) { }

  ngOnInit(): void {
    let user = JSON.parse(this.cookieService.get('user'));
    if(user.usertype == 'admin'){
      this.isAdmin = true;
    }
  }

  logout = () =>{
    this.cookieService.deleteAll();
    this.router.navigate(['login'])
  }

}
